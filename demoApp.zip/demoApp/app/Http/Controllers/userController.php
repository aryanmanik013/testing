<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class userController extends Controller
{
    function show($id){
        return $id;
        // return "Hello From Controller";
    }


    function loadView($name){
        return view('user1',["name"=>$name]);
    }
}
